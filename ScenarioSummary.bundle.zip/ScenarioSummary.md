### Nash Metrics (latest artifact)
| Scenario | NE | PoA |
|---|---|---|
| battle_of_sexes | Pure | ? |
| matching_pennies | Pure | ? |
| prisoners_dilemma | Pure | ? |
| stag_hunt | Pure | ? |
